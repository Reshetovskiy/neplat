;(function ($) {
    
    $('.js-example-basic-single-id').select2({
        dropdownCssClass: 'test',
       
    });
    // begin script finger-mobil

    $('.js-example-basic-single-id').select2({
        dropdownCssClass: 'test',
       
    });

    $('.js-example-basic-single').select2({
        
    }),

    $('.country').select2({
        placeholder: "Страна"
    }),
    $('.city').select2({
        placeholder: "Город"
    }),
// Вид сделки
    $('.noscript').select2({
        minimumResultsForSearch: -1,
        placeholder: 'Вид сделки'
    })

})(jQuery)