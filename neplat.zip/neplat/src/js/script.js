(function ($) {
    'use strict'
    var updateScroll;
    $(window).on("load",function(){
        
        var scroll_action = 'top';
        
        updateScroll= $('.scrollbar').mCustomScrollbar({
            scrollInertia:400,
            axis: 'y',
            scrollbarPosition: "outside",
            alwaysShowScrollbar: true,
            live: true,
            autoDraggerLength: false,
            advanced:{
                updateOnContentResize: true,
                updateOnImageLoad: true
              },
            callbacks:{
                whileScrolling:function (){
                    var scrollBlack = $('.scrollbar .scrollbar__scrollBlack');
                    var scrollBlackTwo = $('.scrollbar-two .scrollbar__scrollBlack-two');
                    var scrollBarElem = $('.scrollbar   .mCSB_scrollTools .mCSB_dragger');
                    var scrollBarElemTwo = $('.scrollbar-two   .mCSB_scrollTools .mCSB_dragger');
                    scrollBlack.css('height',scrollBarElem.position().top+'px');
                    scrollBlackTwo.css('height',scrollBarElemTwo.position().top+'px');
                },
                onUpdate:function() {

                },
                onTotalScroll: function(){
                    return;
                },
                onScroll:function(){
                    if(scroll_action == 'bottom'){
                        if(this.mcs.top == 0){
                            $('.scrollbar  ').mCustomScrollbar("update");
                        }
                    } else if(scroll_action == 'top'){
                        if(this.mcs.topPct == 100){
                            $('.scrollbar  ').mCustomScrollbar("update");
                        }
                    }
                },
                onTotalScrollBack: function(){
                    return;
                },
            }
        });

        $('<div class="scrollbar__scrollBlack"></div>').insertAfter('.scrollbar   .mCSB_scrollTools .mCSB_dragger');
        console.log(updateScroll);
    });

    

    $(document).ready(function () {
        svg4everybody({})
        var doFullpage = document.documentElement.clientWidth;
        if (doFullpage > 1080) {

            $('#fullpage').fullpage({

                licenseKey: 'OPEN-SOURCE-GPLV3-LICENSE',
                autoScrolling: true,
                normalScrollElements: '.scrollbar',
                normalScrollElements: '.scrollbar-two',

            });
        };
        
  
        
        $(window).on("load", function () {
            $(".scrollbar").mCustomScrollbar();
        });
 
        // $.fn.fullpage.setAllowScrolling(true);

        $('.header__right-entrance button').on('click', function () {
            $('.modal-cabinet').fadeIn(500)
        })

        $('.bottom-nav__button').on('click', function (e) {
            e.preventDefault()
            $('.modal-cabinet').fadeOut(500)
        })



        $('.registr').on('click', function () {
            $('.modal-regist ').fadeIn(500)
        })

        $('.bottom-nav__button').on('click', function (e) {
            e.preventDefault()
            $('.modal-regist').fadeOut(500)
        })

        $('.bottom-nav__button').on('click', function (e) {
            e.preventDefault()
            $('.modal-reset').fadeOut(500)
        })

        $('.bottom-nav__button').on('click', function (e) {
            e.preventDefault()
            $('.end-register').fadeOut(500)
        })


        $('#cabinet').on('click', function () {
            $('.modal-regist').fadeIn(500)
            $('.modal-cabinet').fadeOut(500)
        })

        $('#register').on('click', function () {
            $('.modal-cabinet').fadeIn(500)
            $('.modal-regist').fadeOut(500)
        })

        $('.actions__first').on('click', function () {
            $('.modal-reset').fadeIn(500)
            $('.modal-cabinet').fadeOut(500)
        })

        $('.about-company__arrow img').on('click', function () {
            $('.block-hide').toggleClass('show')
            $(this).toggleClass('active')
        })


        $('.header-mobile__menu').on('click', function (e) {
            e.preventDefault()
            $('.header').toggleClass('show')
            $(this).toggleClass('active')
            $('body').toggleClass('active')
        })
        $('.header-mobile__search').on('click', function(e) {
            e.preventDefault()
            $('.header').toggleClass('show')
            $(this).toggleClass('active')
            $('body').toggleClass('active')
        })
           // tabs file 
    $('.left-block li').on('click', function () {
        $(this).addClass('active').siblings().removeClass('active');
        if (!$(this).hasClass("wrapper-table-active")) {
            var i = $(this).index();
            $(".left-block li.wrapper-table-active").removeClass('wrapper-table-active');
            $(".wrapper-tabs .wrapper-table-active").hide().removeClass('wrapper-table-active');
            $(this).addClass('wrapper-table-active').find('.scroll').addClass('scrollbar');
            $($(".wrapper-tabs").children(".wrapper-table")[i]).fadeIn(700).addClass('wrapper-table-active');
            $('#scrollbar-two').find('.scrollbar__scrollBlack').removeAttr('style').addClass('scrollbar__scrollBlack-two').removeClass('scrollbar__scrollBlack');
        }
      });
    });
 

    $('.left-img-scroll').on('click', function () {
        $('.left-scroll').toggleClass('travel-panel').css({ "transition": "all .5s" });
        if($('.left-scroll').hasClass('travel-panel')) {
            $('.img-first').css('display', 'none');
            $('.img-second').css('display', 'block');
        } else {
            $('.img-first').css('display', 'block');
            $('.img-second').css('display', 'none');
        }
    })

    $('.select-modal ').on('click', function() { 
        $('option.none').hide()
    })
 
    $( function () {
        $( "#date" ).datepicker();
    })

    $('input[type=file]').on('change', function(){
        var fileName = $(this).val(); 
        var $fileWay  = $(this).parents('.user-info__group');
        $fileWay.children('.user-info__status').text('Загружен');
        $fileWay.children('.delete').css('display', 'block');
        $fileWay.children('.delete').on('click', function () {
            $(this).css('display', 'none');
            $fileWay.children('.user-info__status').text('Загрузите файл');
            $fileWay.find('input').val('');
        })
    });

  
})(jQuery)
//=require partials/select2.js